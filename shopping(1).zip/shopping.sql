-- MySQL dump 10.13  Distrib 8.4.2, for Win64 (x86_64)
--
-- Host: localhost    Database: shopping
-- ------------------------------------------------------
-- Server version	8.4.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adv`
--

DROP TABLE IF EXISTS `adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adv` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `context` varchar(255) DEFAULT NULL COMMENT '内容',
  `creat_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `pic_url` varchar(255) DEFAULT NULL,
  `resta_id` int DEFAULT NULL COMMENT '餐厅id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adv`
--

LOCK TABLES `adv` WRITE;
/*!40000 ALTER TABLE `adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buy`
--

DROP TABLE IF EXISTS `buy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `buy` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `good_id` int DEFAULT NULL COMMENT '商品id',
  `resta_id` int DEFAULT NULL COMMENT '餐厅id',
  `creat_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `end_time` datetime DEFAULT NULL COMMENT '清除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buy`
--

LOCK TABLES `buy` WRITE;
/*!40000 ALTER TABLE `buy` DISABLE KEYS */;
INSERT INTO `buy` VALUES (2,3,2,'2024-10-22 17:55:00','2024-10-22 17:55:00',NULL),(4,5,NULL,'2024-10-23 12:06:14','2024-10-23 12:06:14',NULL),(6,4,NULL,'2024-10-23 12:11:12','2024-10-23 12:11:12',NULL),(7,10,NULL,NULL,NULL,NULL),(8,16,NULL,'2024-10-23 18:12:38','2024-10-23 18:12:38',NULL);
/*!40000 ALTER TABLE `buy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '菜品种类名称',
  `is_discount` varchar(255) DEFAULT '0' COMMENT '默认0 不打折-1打折',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'电子烟','0'),(2,'传统香烟','0'),(3,'赛博烟','0'),(4,'宝贝奶茶','0'),(5,'普通奶茶','0'),(6,'咖啡','0');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `comment` varchar(255) DEFAULT NULL COMMENT '评论',
  `creat_time` datetime DEFAULT NULL COMMENT '创建时间',
  `resta_id` int DEFAULT NULL COMMENT '店铺评论',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,'无敌了孩子','2024-10-23 12:11:12',1),(2,'感觉不如丁真','2024-10-22 17:58:13',2),(3,'来抽传统香烟','2024-10-22 17:59:48',2),(4,'感觉不如瑞克五代','2024-10-22 18:06:04',3),(5,'关注永雏塔菲喵，关注永雏塔菲谢谢喵','2024-10-23 12:11:12',4),(6,'关注东雪莲喵，关注东雪莲谢谢喵','2024-10-23 12:11:12',4),(8,'扣1送电子烟','2024-10-24 12:16:41',1);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods`
--

DROP TABLE IF EXISTS `goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) DEFAULT NULL COMMENT '餐厅名称',
  `pic_url` varchar(255) DEFAULT NULL COMMENT '图片',
  `price` decimal(10,2) DEFAULT NULL COMMENT '价格',
  `context` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '详细信息',
  `is_discount` varchar(255) DEFAULT '0' COMMENT '默认0 不打折-1打折',
  `category_id` int DEFAULT NULL COMMENT '种类id',
  `resta_id` int DEFAULT NULL COMMENT '餐厅id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods`
--

LOCK TABLES `goods` WRITE;
/*!40000 ALTER TABLE `goods` DISABLE KEYS */;
INSERT INTO `goods` VALUES (3,'塔菲粉润宝贝茶',NULL,137666.00,'由塔菲良心推荐的宝贝奶茶','0',4,4),(4,'吴涛厚乳粉唇茶',NULL,137666.00,'由塔菲良心推荐的宝贝奶茶','0',4,4),(5,'莲莲精华宝贝茶',NULL,137666.00,'由莲莲良心推荐的宝贝奶茶','0',4,4),(6,'白开水',NULL,1.00,'普通水','1',5,5),(7,'鲨鱼水',NULL,1376.00,'由773良心推荐的宝贝奶茶','0',4,4),(8,'乌龙茶',NULL,13.00,'无','1',5,5),(9,'珍珠奶茶',NULL,13.00,'无','1',5,5),(10,'双皮奶',NULL,137.00,'宝贝','0',4,4),(11,'大红袍奶茶',NULL,13.00,'无','1',5,5),(12,'瑞幸咖啡',NULL,13.00,'咖啡','0',6,6),(13,'星巴克咖啡',NULL,13.00,'咖啡','1',6,6),(14,'手冲咖啡',NULL,1376.00,'手冲','0',6,7),(15,'瑞克五代',NULL,1376.00,'由瑞克匠心打造的传奇电子烟','0',1,1),(16,'中华',NULL,137.00,'由王源良心推荐的宝贝传统香烟','0',2,3),(17,'丁真爱吸的烟',NULL,137666.00,'由丁真良心推荐的宝贝电子香烟','1',3,1);
/*!40000 ALTER TABLE `goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant`
--

DROP TABLE IF EXISTS `restaurant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurant` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) DEFAULT NULL COMMENT '餐厅名称',
  `pic_url` varchar(255) DEFAULT NULL COMMENT '图片',
  `context` varchar(255) DEFAULT NULL COMMENT '店铺描述',
  `addr` varchar(255) DEFAULT NULL COMMENT '地址',
  `iphone` varchar(255) DEFAULT NULL COMMENT '联系方式',
  `creat_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `is_discount` varchar(255) DEFAULT '0' COMMENT '默认0 不打折-1打折',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant`
--

LOCK TABLES `restaurant` WRITE;
/*!40000 ALTER TABLE `restaurant` DISABLE KEYS */;
INSERT INTO `restaurant` VALUES (1,'瑞克',NULL,'瑞克公司专门做电子烟','四川礼堂','13766666',NULL,NULL,'0'),(2,'超级无敌雪豹大王',NULL,'雪豹是丁真的伙伴','丁真的家','137666',NULL,NULL,'0'),(3,'王源',NULL,'喜欢抽华子','中华传统','1376',NULL,NULL,'0'),(4,'皮套联名奶茶',NULL,'皮套联名宝贝奶茶','赛博空间','1376666',NULL,NULL,'0'),(5,'普通奶茶',NULL,'普通奶茶店','工地外围','137',NULL,NULL,'0'),(6,'雀巢咖啡',NULL,'专门卖咖啡的店','写字楼外围','1376',NULL,NULL,'0'),(7,'手冲咖啡',NULL,'宝贝咖啡','万达广场正中央','13766',NULL,NULL,'0');
/*!40000 ALTER TABLE `restaurant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) DEFAULT NULL COMMENT '用户名',
  `iphone` varchar(255) DEFAULT NULL COMMENT '电话',
  `addr` varchar(255) DEFAULT NULL COMMENT '地址',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '头像',
  `is_vip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '0' COMMENT '默认0普通会员 1vip',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'dingzhen','137666','四川理塘',NULL,'0'),(2,'xuebao','13766','四川理塘',NULL,'0');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'shopping'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-24 14:28:03
